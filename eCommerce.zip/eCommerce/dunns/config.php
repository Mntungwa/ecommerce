<?php
$currency = 'R'; //Currency sumbol or code

/*
 'connectionString' => 'mysql:host=files.000webhost.com;
  'dbname'=>'id2695973_dunns',
  'username' => 'id2695973_ecommerce',
  'password' => '19920611',
*/

//db settings
$db_username = 'id2695973_ecommerce';
$db_password = '19920611';
$db_name = 'id2695973_dunns';
$db_host = 'files.000webhost.com';

$mysqli = new mysqli($db_host, $db_username, $db_password,$db_name);


//paypal settings
$PayPalMode 			= 'sandbox'; // sandbox or live
$PayPalApiUsername 		= 'paypaluser@Dunnesemail.com'; //PayPal API Username
$PayPalApiPassword 		= '190798792445'; //Paypal API password
$PayPalApiSignature 	= '797987709709709oipuiou98Eq.Gufar'; //Paypal API Signature
$PayPalCurrencyCode 	= 'R'; //Paypal Currency Code
$PayPalReturnURL 		= 'http://localhost/shopping-cart/paypal-express-checkout/process.php'; //Point to process.php page
$PayPalCancelURL 		= 'http://localhost/shopping-cart/paypal-express-checkout/cancel_url.html'; //Cancel URL if user clicks cancel

?>